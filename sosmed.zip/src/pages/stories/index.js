import React from "react";

export default function StoriesPage() {
  return <div>index</div>;
}

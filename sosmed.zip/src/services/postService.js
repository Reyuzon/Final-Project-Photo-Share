import { axiosInstance } from "@/lib/axios";
import { getCookie } from "cookies-next";

export const getExplorePost = async (pageParams = 1) => {
  const response = await axiosInstance.get(
    "/api/v1/explore-post?size=27&page=" + pageParams,
    {
      headers: {
        Authorization: "Bearer " + getCookie("token"),
      },
    }
  );
  return response;
};
